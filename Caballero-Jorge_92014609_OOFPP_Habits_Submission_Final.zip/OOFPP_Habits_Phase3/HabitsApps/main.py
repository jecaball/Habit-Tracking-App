from user import *

# first step: create or  access to an account
User = None
while User is None:
    print('{} WELCOME TO HABITS TRACKING APP {}'.format('*'*20,'*'*20))
    print('{} LOGIN | SINGUP MENU {}'.format('*'*20,'*'*20))
    print('follow the instructions to navigate the app.')
    print('Do you have an account? answer "yes" or "not".')

    # gets the user input from command line, stores the answer in the variable answer, makes the string in the variable answer lower case
    answer = input().lower()

    # navegates through the different possibilities
    if answer == "yes":

        # iterates to enter into an existing account
        # provides the user a way to input data to retrieve the information of its account
        while True:  
            print('Please, provide an e-mail:')
            email = input().lower()
            print('Please, provide a password:')
            password = input().lower()

            # creates User as an instance of user, fills the property email and password to be checked if they exists in the system
            User = user()
            User.email = email
            User.password = password

            # checks if the provided information is correct, stores the value of the process in the variable result
            result = User.checkPasswordEmail()

            # acts according the value of the variable result
            if result == True:
                # if true the account exists, the loop is left and it is proceeded to the next step
                break
            elif result == False:
                # asks the user if he wants to create an account instead
                print('Do you want to go back and create an account? Write "yes" or "not".')                
                
                # gets input from user
                answer=input().lower()

                # checks the answer and proceeds accordingly
                if answer=='yes':
                    # goes back to main menu
                    User=None
                    break
                elif answer=='not':
                    # if false the account does not exist, and the loop is started over again
                    continue 
                else:
                    print('Incorrect input!')
                    # if false the account does not exist, and the loop is started over again
                    continue 


    elif answer == 'not':
        # iterates through the different commands
        while True:
            print('Do you want to make an account? write "yes" or "not".')
            answer = input()
            answer = answer.lower()

            # adds the required information to create a new account for the user
            if answer == 'yes':
                # inputs the user data
                print('Please, provide your name:')
                name = input()
                print('Please, provide your last name:')
                lastname = input()
                print('Please, provide an e-mail:')
                email = input()
                print('Please, provide the password:')
                password = input()

                # creates the variable User as an instance of the user class
                User = user(name, lastname, email, password)
                User.addNewUser()

                # adds exemplary records for the user
                User.exemplaryRecords()

                # break and goes to next steps
                break

            elif answer == 'not':
                # goes back to the first questiona
                break
            else:
                # if the user writes something else, it starts the loop again
                continue

# second step: Navigates through the different options
while True:
    # informs the user of the different options available to continue
    print('*'*40)
    print('{} OPTIONS MENU {}'.format('*'*20,'*'*20))
    print('What would you like to do?\
    Write down any of following options using the letters in parentesis: \n \
    -Add a habit (a)\n \
    -Check a habit (c) \n \
    -Delete a habit (d)\n \
    -Show a list with all tracked habits (l1)\n \
    -Show a list of habits by periocidity (l2)\n \
    -Return the longest run streak (r1)\n \
    -Return the longest run streak for a given habit (r2)\n \
    -Exit (e)\
    ')

    # receives the input from the user and makes it lowercase
    answer = input().lower()

    # checks which options was given
    if answer == 'a':

        # goes to the process to add a new habit
        print('Please, write the name of the habit that you want to add:')
        User.addHabits(input())

        print('Please, describe the habit that you want to add:')
        User.addHabitSpecification(input())
        
        #while-loop for adding periocidity
        while True:

            # prints available options of periocidity
            print('Please, add a periocidity to the habit that you want to add.\n\
            Try one of these options:\n\
            -daily\n\
            -weekly\n\
            -monthly')

            #checks for correct input
            if True ==User.periocityHabit(input()): 
                # leaves while-loop
                break 
            else:
                #stays in while-loop
                continue


        #Establishes the start of the habit
        User.startHabit()
        print('Starting date: {}'.format(User.startTime))

        #establishes the end of the habit
        while True:
            
            #informs user about the required finalization date
            print('Please, indicate when you want to finilize the tracking of this habit.\n \
            Use the following format: YYYY-MM-dd')

            if True==User.finishHabit(input()):
                #leaves while-loop
                break

            else:
                #stays in while-loop
                continue
        
        #adds new information to long term storage and gets the idperiodicity from the database
        idperiocidity=User.addRecordsPeriocidity(User.startTime, 
                                                 User.finishTime,
                                                 User.periods, 
                                                 User.conPeriocityInt(User.periocity))
        
        #adds new habit in the database habits and gets the idhabits from the database
        idhabits=User.addRecordsHabits(User.habit,User.specification,idperiocidity,User.iduser)
      
        #informs that the information was added to the long term storage
        print('{} The habit was saved in the database {}'.format('>'*10,'<'*10))

    #checks a tracked habit
    elif answer== 'c':
        
        #repeats the process until a valid option is selected
        while True:

            #tells the user to select a habit from a list of available tracked habits
            print('Write the habit id-number of a habit to be checked:')

            #gets the list of habits
            listhabits=User.loadSpecific('habits', ['idhabits','name','periocidity'], 'iduser', User.iduser)

            #prints the list of available habits of the user
            for i in listhabits:
                print('-> habit id-number: {} | habit name: "{}"'.format(i[0],i[1]))

            print('Or press "x" to go back to OPTIONS MENU')

            #gets the user´s selection
            habitSelection= input()

            #checks that a valid option was selected
            if any(int(habitSelection) in sublist for sublist in listhabits):

                #adds a record in the checked table with checked as False
                User.checkedHabit(True)

                # checks if the habit was already checked
                #gets the period
                periocidity=User.loadSpecific('periocidity',['categories'],'idperiocidity',habitSelection)[0][0]
                
                #gets list of checked habits for the habit been checked
                checked =User.loadSpecific('checked',['checkeddate'],'idhabits',habitSelection)

                # periocidity in days 
                if periocidity==1 and any(User.chkTime>i[0] for i in checked):
                    
                    #adds record to table
                    idchecked=User.addRecordsChecked(User.chkTime,User.check,habitSelection)
                
                elif periocidity==2 and any(User.chkTime.isocalendar()[1]> i[0].isocalendar()[1] for i in checked):
                    
                    #adds record to table
                    idchecked=User.addRecordsChecked(User.chkTime,User.check,habitSelection)
                
                elif periocidity==3 and any(User.chkTime.month> i[0].month for i in checked):
                
                    #adds record to table
                    idchecked=User.addRecordsChecked(User.chkTime,User.check,habitSelection)
                
                else:
                    #informs that the habit was already checked.
                    print('{} The habit was already checked in the required period {}'.format('>'*20,'<'*20))

                #leaves the while-loop
                break

            elif habitSelection.lower()=='x':
                
                #leaves the while-loop
                break

            else:
                #informs that the written habit does not exist
                print('The selected habit does not exit. Please, try again!')
    
    #deletes a habit   
    elif answer == 'd':

        #repeats the process until a valid option is selected
        while True:

            #tells the user to select a habit from a list of available tracked habits
            print('Write the number of a habit that you want to mark as checked:')
            #gets the list of habits
            listhabits=User.loadSpecific('habits', ['idhabits','name', 'periocidity'], 'iduser', User.iduser)

            #prints the list of available habits of the user
            for i in listhabits:
                print('-> habit id-number: {} | habit name: "{}"'.format(i[0],i[1])  )

            print('Or press "x" to go back to the main menu')

            #gets the user´s selection
            habitSelection= int(input())


            #checks that a valid option was selected
            if any(habitSelection in sublist[0:2] for sublist in listhabits):

                #deletes all records of the table checked of the indicated habit
                User.deleteRecord('checked','idhabits',habitSelection)

                #deletes selected record of the table periocidity. This will delete the respective records in the table habits as well
                User.deleteRecord('periocidity','idperiocidity',habitSelection)

                #informs the user
                print('The habit was deleted')

                #leaves the while-loop
                break
            elif habitSelection.lower()=='x':
                
                #leaves the while-loop
                break

            else:
                #informs that the written habit does not exist
                print('The selected habit does not exit. Please, try again!')

    #return a list of all currently tracked habits
    elif answer == 'l1':

        # gets the list of all the habits of the user
        listhabits=User.loadSpecific('habits', ['idhabits','name','description','periocidity'], 'iduser', User.iduser)

        #gets the information from the periocidity table for the habits in the list of habits
        listperio=[]
        for ids in listhabits:
            listperio.extend(User.loadSpecific('periocidity', ['start','finish','periods'], 'idperiocidity', ids[3]))

        #joins lists
        listhabits=User.joindb(listhabits,listperio)

        #filters list according to end date
        listhabits=User.filtdate(listhabits)

        #informs 
        print('{} Here is the list of habtis currently being tracked {}'.format('>'*20,'<'*20))
        
        #prints the list of available habits of the user
        print('({}, {}, {}, {}, {})'.format('Name','Description',
                                            'Start date','End Date','Periods'))
        for i in listhabits:
            print('->({}, {}, {}, {}, {})'.format(
                i[1],i[2],i[4],i[5],i[6]))  

    #return a list of all habits with the same periodicity,
    elif answer == 'l2':
        #informs the user about the list of habits by periocidity
        print('{} Here is the list of habits by periocidity: {}'.format('>'*20,'<'*20))

        #gets the list of all habits
        listhabits=User.loadSpecific('habits', ['idhabits','name','description','periocidity'], 'iduser', User.iduser)

        #gets the list of all periocidities from table periocidity
        listperio=[]
        for perioid in listhabits:
            listperio.extend(User.loadSpecific('periocidity',['categories'],'idperiocidity',perioid[3]))
        
        #joins the lists
        listhabits=User.joindb(listhabits,listperio)

        #deletes a list
        del listperio

        #sorts the list by periocity
        listhabits=sorted(listhabits,key= lambda x :x[4]) #to be checked

        print('(Name, Description, Periocidity)')
        #changes periocidity from number to text for presentation purposes and prints the list
        for i in listhabits:
           p=User.conPeriocityTex(i[4])
           print ('->({}, {}, {})'.format(i[1],i[2],p))

    # returns the longest run streak
    elif answer == 'r1':
        #gets the list of habits for the defined user
        listhabits=User.loadSpecific('habits', ['idhabits','name', 'periocidity'], 'iduser', User.iduser)

        #gets the list of periocidity
        listperiocity=User.load('periocidity')

        #gets the list of checked habits
        listchecked=User.load('checked')

        #gets the longest streak and puts it in the veraible result
        result=User.longStreak(listhabits,listperiocity,listchecked)

        #prints to inform the user
        print('The longest run streak belongs to habit "{}" and is {} {} long'.format(result[2],result[0],result[1]))


    # returns the longest run streak for a given habit (r2)  
    elif answer == 'r2':
            #tells the user to select a habit from a list of available tracked habits
            print('Write the id-number of a habit that you want to review:')
            
            #gets the list of habits for tee defined user
            listhabits=User.loadSpecific('habits', ['idhabits','name', 'periocidity'], 'iduser', User.iduser)

            #prints the list of available habits of the user
            for i in listhabits:
                print(i[0:2])  

            print('Or press "x" to go back to the main menu')

            #gets the user´s selection
            habitSelection= int(input())

             #checks that a valid option was selected
            if any(habitSelection in sublist[0:2] for sublist in listhabits):
                #gets the periocidity
                periocidity=User.loadSpecific('periocidity',['categories'],'idperiocidity',habitSelection)

                #gets the list of checked habits
                checked=User.loadSpecific('checked',['idchecked','checkeddate','checked','idhabits'],'idhabits',habitSelection)

                #gets the streak of the selected habit
                streak=User.countTime(periocidity[0][0],checked)
                
                #print the results
                print('The longest streak for the habit are {} {}'.format(streak[0],streak[1]))

            elif habitSelection.lower()=='x':
                #leaves the while-loop
                break
            else:
                #informs that the written habit does not exist
                print('The selected habit does not exit. Please, try again!')

    elif answer == 'e':
        break
    